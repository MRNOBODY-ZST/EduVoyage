package cn.edu.shmtu.eduvoyage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduvoyageApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduvoyageApplication.class, args);
	}

}
